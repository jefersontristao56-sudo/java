package Exemplos;

import java.util.Scanner;

/*Uma loja de calçados está concedendo 12% de desconto nos produtos. 
Escreva um programa para calcular e exibir o valor de desconto a ser dado num par de sapatos e quanto deve custar o produto com o desconto. 
O preço do par de sapatos deve ser informado pelo usuário. Como resultado, o programa deverá exibir as seguintes mensagens:
O valor do desconto é de R$ xxx
O preço do par de sapatos com desconto é R$ xxx
 */
public class Uni3Exe02 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Informe o valor do sapato: ");
        double sapato = sc.nextDouble();

        double valorDesconto = (sapato * 12)/100;

        System.out.println("Valor do desconto vai ser de: " + valorDesconto);
        System.out.println("O valor final do sapato é: " + (sapato - valorDesconto));
        sc.close();
    }
}
