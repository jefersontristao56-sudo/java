package Exemplos;

import java.util.Scanner;

/*Um motorista deseja abastecer seu tanque de combustível. 
Escreva um programa para ler o preço do litro da gasolina 
e o valor do pagamento e exibir quantos litros ele conseguiu colocar no tanque.
 */
public class Uni3Exe03 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        double precoGasolina;
        double quantidadeLitros;
        double valorPago;

        System.out.println("Informe o valor do preço do litro da gasolina: ");
        precoGasolina = sc.nextDouble();

        System.out.println("Informe o valor pago: ");
        valorPago = sc.nextDouble();

        quantidadeLitros = valorPago / precoGasolina;

        System.out.println("O motorista conseguiu colocar: " + quantidadeLitros + " litros de gasolina!");

        sc.close();


    }
}
