package Exemplos;

import java.util.Scanner;

/*Uma granja possui um controle automatizado de cada frango da sua produção. 
No pé direito do frango há um anel com um chip de identificação; 
no pé esquerdo são dois anéis para indicar o tipo de alimento que ele deve consumir. 
Sabendo que o anel com chip custa R$ 4,00 e o anel de alimento custa R$ 3,50, 
faça um programa para calcular o gasto total da granja para marcar todos os seus frangos.
 */
public class Uni3Exe05 {
    public static void main(String[] args) {
        
        Scanner sc = new Scanner(System.in);

        System.out.println("Informe a quantidade total de frangos na granja: ");
        int quantidadeFrango = sc.nextInt();

        final double precoAnelChip = 4.00;
        final double precoAnelAlimento = 3.50;

        double gastoTotalUnitario = (precoAnelAlimento * 2) + precoAnelChip;
        double gastoTotalGranja = gastoTotalUnitario * quantidadeFrango;

        System.out.println("O gasto total na granja é de:" + gastoTotalGranja);

        sc.close();

    }
}
