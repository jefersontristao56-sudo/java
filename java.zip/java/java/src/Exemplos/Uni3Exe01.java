package Exemplos;

import java.util.Scanner;

//Uma imobiliária vende apenas terrenos retangulares. 
// Faça um programa para ler as dimensões de um terreno e depois exibir a área do terreno.
public class Uni3Exe01 {
    public static void main(String[] args) {
        
        Scanner sc = new Scanner(System.in);

        int altura;
        int largura;

        System.out.println("Informe a altura: ");
        altura = sc.nextInt();

        System.out.println("Informe a largura: ");
        largura = sc.nextInt();

        int area = altura * largura;

        System.out.println("A área do terreno é de: " + area);
        sc.close();
    }
}
