package Exemplos;

import java.util.Scanner;

/*Faça um programa para ler três notas de um aluno 
em uma disciplina e imprimira sua média ponderada 
(as notas tem pesos respectivos de 5, 3 e 2).
/*
 */
public class Uni3Exe04 {
    public static void main(String[] args) {
        
        Scanner sc = new Scanner(System.in);

        System.out.println("Informe a primeira nota com peso 5: ");
        double nota1 = sc.nextDouble();

        System.out.println("Informe a primeira nota com peso 3: ");
        double nota2 = sc.nextDouble();

        System.out.println("Informe a primeira nota com peso 2: ");
        double nota3 = sc.nextDouble();

        double mediaPonderada = ((nota1 * 5) + (nota2 * 3) + (nota3 * 2)) / 10;

        System.out.println("A média ponderada é: " + mediaPonderada);

        sc.close();

    }
}
